from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import pandas as pd
import joblib

from typing import Optional

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# LOAD MODEL
# =========================

model = joblib.load("topic_recommendation_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")
feature_columns = joblib.load("feature_columns.pkl")

# =========================
# REQUEST BODY
# =========================

class StudentData(BaseModel):
    raisedhands: int
    VisITedResources: int
    AnnouncementsView: int
    Discussion: int
    StudentAbsenceDays: str

    skor: Optional[int] = 0
    topic: Optional[str] = None

# =========================
# TOPIC GROUPING
# =========================

reverse_topic_mapping = {
    "STEM": [
        "Math",
        "Biology",
        "Chemistry",
        "Science",
        "Geology",
        "IT"
    ],

    "Language": [
        "Arabic",
        "French",
        "English",
        "Spanish"
    ],

    "Religion": [
        "Quran"
    ],

    "Social": [
        "History"
    ]
}

# =========================
# TOPIC META
# =========================

topic_meta = {
    "IT": {
        "emoji": "💻",
        "desc": "Pelajari dasar-dasar teknologi informasi dan komputer."
    },
    "Math": {
        "emoji": "➗",
        "desc": "Kuasai konsep matematika dari dasar hingga lanjutan."
    },
    "Science": {
        "emoji": "🔬",
        "desc": "Eksplorasi ilmu pengetahuan alam dan fenomenanya."
    },
    "English": {
        "emoji": "📖",
        "desc": "Tingkatkan kemampuan bahasa Inggris kamu."
    },
    "Arabic": {
        "emoji": "🌙",
        "desc": "Belajar bahasa dan budaya Arab secara mendalam."
    },
    "French": {
        "emoji": "🗼",
        "desc": "Kuasai bahasa Prancis untuk komunikasi global."
    },
    "Spanish": {
        "emoji": "💃",
        "desc": "Pelajari bahasa Spanyol yang kaya budaya."
    },
    "Quran": {
        "emoji": "📿",
        "desc": "Pelajari dan pahami Al-Quran dengan baik."
    },
    "Biology": {
        "emoji": "🧬",
        "desc": "Jelajahi dunia biologi dan makhluk hidup."
    },
    "Chemistry": {
        "emoji": "⚗️",
        "desc": "Pahami reaksi kimia dan unsur-unsur materi."
    },
    "Geology": {
        "emoji": "🪨",
        "desc": "Pelajari struktur bumi dan fenomena geologis."
    },
    "History": {
        "emoji": "🏛️",
        "desc": "Telusuri peristiwa bersejarah yang membentuk dunia."
    }
}

# =========================
# API
# =========================

@app.post("/predict")
def predict_topic(data: StudentData):

    # =========================
    # DATA UNTUK MODEL
    # =========================

    df_input = pd.DataFrame([{
        "raisedhands": data.raisedhands,
        "VisITedResources": data.VisITedResources,
        "AnnouncementsView": data.AnnouncementsView,
        "Discussion": data.Discussion,
        "StudentAbsenceDays": data.StudentAbsenceDays
    }])

    # =========================
    # FEATURE ENGINEERING
    # =========================

    df_input["Participation_Score"] = (
        df_input["raisedhands"] +
        df_input["Discussion"]
    ) / 2

    df_input["Engagement_Score"] = (
        df_input["VisITedResources"] +
        df_input["AnnouncementsView"]
    ) / 2

    # =========================
    # USER LEVEL
    # =========================

    if data.skor >= 80:
        level_user = "H"
        difficulty = "Sulit"
        diff_color = "#ef4444"

    elif data.skor >= 60:
        level_user = "M"
        difficulty = "Sedang"
        diff_color = "#f59e0b"

    else:
        level_user = "L"
        difficulty = "Mudah"
        diff_color = "#10b981"

    # =========================
    # ENCODING
    # =========================

    df_input = pd.get_dummies(df_input)

    df_input = df_input.reindex(
        columns=feature_columns,
        fill_value=0
    )

    # =========================
    # PREDICTION
    # =========================

    prediction = model.predict(df_input)

    predicted_category = (
        label_encoder.inverse_transform(prediction)[0]
    )

    probabilities = model.predict_proba(df_input)

    confidence = float(max(probabilities[0]))

    # =========================
    # SUBJECT RECOMMENDATION
    # =========================

    recommended_subjects = reverse_topic_mapping.get(
        predicted_category,
        []
    )

    # Hilangkan topik yang sedang dipelajari
    if data.topic:
        recommended_subjects = [
            subject
            for subject in recommended_subjects
            if subject.lower() != data.topic.lower()
        ]

    recommendations = []

    for subject in recommended_subjects:

        meta = topic_meta.get(
            subject,
            {
                "emoji": "📚",
                "desc": "Pelajari topik ini."
            }
        )

        recommendations.append({
            "topic": subject,
            "emoji": meta["emoji"],
            "desc": meta["desc"],

            # dibuat kompatibel dengan frontend lama
            "skorRekomen": round(((confidence * 100) + data.skor) / 2),
            "highPct": round(confidence * 100),

            "difficulty": difficulty,
            "diffColor": diff_color,

            # dummy field supaya frontend lama aman
            "totalSiswa": None,

            "alasan": (
                f"Topik ini direkomendasikan karena aktivitas belajar "
                f"Anda paling sesuai dengan jalur {predicted_category}."
            )
        })

    # =========================
    # RESPONSE
    # =========================

    return {
        "success": True,
        "levelUser": level_user,
        "skor": data.skor,
        "topikSekarang": data.topic,
        "learningPath": predicted_category,
        "confidence": round(confidence * 100, 2),
        "data": recommendations
    }