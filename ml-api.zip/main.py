from fastapi import FastAPI
from pydantic import BaseModel

import pandas as pd
import joblib

app = FastAPI()

# Load model
model = joblib.load('topic_recommendation_model.pkl')

# Load encoder
label_encoder = joblib.load('label_encoder.pkl')

# Load feature columns
feature_columns = joblib.load('feature_columns.pkl')


class StudentData(BaseModel):
    raisedhands: int
    VisITedResources: int
    AnnouncementsView: int
    Discussion: int
    StudentAbsenceDays: str

reverse_topic_mapping = {
    "STEM": [
        "Math",
        "Biology",
        "Chemistry",
        "Science",
        "Geology",
        "IT"
    ],

    "Language": [
        "Arabic",
        "French",
        "English",
        "Spanish"
    ],

    "Religion": [
        "Quran"
    ],

    "Social": [
        "History"
    ]
}

@app.post("/predict")
def predict_topic(data: StudentData):

    df_input = pd.DataFrame([data.dict()])

    # Feature engineering
    df_input['Participation_Score'] = (
        df_input['raisedhands'] +
        df_input['Discussion']
    ) / 2

    df_input['Engagement_Score'] = (
        df_input['VisITedResources'] +
        df_input['AnnouncementsView']
    ) / 2

    # One-hot encoding
    df_input = pd.get_dummies(df_input)

    # Samakan kolom
    df_input = df_input.reindex(
        columns=feature_columns,
        fill_value=0
    )

    # Predict category
    prediction = model.predict(df_input)

    predicted_category = label_encoder.inverse_transform(prediction)[0]

    # Confidence
    probabilities = model.predict_proba(df_input)

    confidence = float(max(probabilities[0]))

    # Reverse mapping
    recommended_subjects = reverse_topic_mapping[predicted_category]

    return {
        "recommended_category": predicted_category,
        "recommended_subjects": recommended_subjects,
    }